package com.galih.myself;

/*21 Mei 2022*/
/*10119175*/
/*Mochamad Galih Prasetya*/
/*IF-5*/

public class MusicData {
    public String title;
    public String singer;

    public MusicData(String title, String singer){
        this.title = title;
        this.singer = singer;
    }
}
