package com.galih.myself;

/*21 Mei 2022*/
/*10119175*/
/*Mochamad Galih Prasetya*/
/*IF-5*/

public class DailyData {
    public Integer image;
    public String title, desc;

    public DailyData(Integer image, String title, String desc) {
        this.image = image;
        this.title = title;
        this.desc = desc;
    }
}
